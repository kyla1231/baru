<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in and is admin
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Only admin can access this page
if (!isAdmin()) {
    setFlashMessage('danger', 'You do not have permission to access that page.');
    header('Location: dashboard.php');
    exit;
}

// Initialize variables
$settings = [
    'company_name' => 'Laundry Management System',
    'company_address' => 'Jl. Contoh No. 123, Kota',
    'company_phone' => '0812-3456-7890',
    'company_email' => 'info@laundry.com',
    'tax_percentage' => 0,
    'currency_symbol' => 'Rp',
    'date_format' => 'd/m/Y',
    'receipt_footer' => 'Terima kasih telah menggunakan jasa kami!'
];

// Check if settings table exists
try {
    $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='settings'");
    $tableExists = (bool)$stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$tableExists) {
        // Create settings table
        $db->exec("CREATE TABLE settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            setting_key TEXT NOT NULL UNIQUE,
            setting_value TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Insert default settings
        $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)");
        foreach ($settings as $key => $value) {
            $stmt->execute([$key, $value]);
        }
    } else {
        // Fetch existing settings
        $stmt = $db->query("SELECT setting_key, setting_value FROM settings");
        $settingsData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($settingsData as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch (PDOException $e) {
    setFlashMessage('danger', 'Database error: ' . $e->getMessage());
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $newSettings = [
        'company_name' => trim($_POST['company_name']),
        'company_address' => trim($_POST['company_address']),
        'company_phone' => trim($_POST['company_phone']),
        'company_email' => trim($_POST['company_email']),
        'tax_percentage' => (float)$_POST['tax_percentage'],
        'currency_symbol' => trim($_POST['currency_symbol']),
        'date_format' => trim($_POST['date_format']),
        'receipt_footer' => trim($_POST['receipt_footer'])
    ];
    
    try {
        // Update settings in database
        $stmt = $db->prepare("INSERT OR REPLACE INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)");
        foreach ($newSettings as $key => $value) {
            $stmt->execute([$key, $value]);
        }
        
        $settings = $newSettings;
        setFlashMessage('success', 'Settings saved successfully.');
    } catch (PDOException $e) {
        setFlashMessage('danger', 'Error saving settings: ' . $e->getMessage());
    }
}

// Include header
$pageTitle = "System Settings";
include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800 animate-fade-in">System Settings</h1>
    </div>

    <?php displayFlashMessages(); ?>

    <div class="card shadow mb-4 animate-fade-in" style="animation-delay: 0.1s">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">General Settings</h6>
        </div>
        <div class="card-body">
            <form method="post" id="settingsForm">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="company_name" class="form-label">Company Name</label>
                            <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo htmlspecialchars($settings['company_name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="company_address" class="form-label">Company Address</label>
                            <textarea class="form-control" id="company_address" name="company_address" rows="2"><?php echo htmlspecialchars($settings['company_address']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="company_phone" class="form-label">Company Phone</label>
                            <input type="text" class="form-control" id="company_phone" name="company_phone" value="<?php echo htmlspecialchars($settings['company_phone']); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="company_email" class="form-label">Company Email</label>
                            <input type="email" class="form-control" id="company_email" name="company_email" value="<?php echo htmlspecialchars($settings['company_email']); ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="tax_percentage" class="form-label">Tax Percentage (%)</label>
                            <input type="number" min="0" max="100" step="0.01" class="form-control" id="tax_percentage" name="tax_percentage" value="<?php echo htmlspecialchars($settings['tax_percentage']); ?>">
                            <div class="form-text">Enter tax percentage (e.g., 10 for 10%)</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="currency_symbol" class="form-label">Currency Symbol</label>
                            <input type="text" class="form-control" id="currency_symbol" name="currency_symbol" value="<?php echo htmlspecialchars($settings['currency_symbol']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="date_format" class="form-label">Date Format</label>
                            <select class="form-select" id="date_format" name="date_format" required>
                                <option value="d/m/Y" <?php echo ($settings['date_format'] == 'd/m/Y') ? 'selected' : ''; ?>>DD/MM/YYYY (31/12/2023)</option>
                                <option value="m/d/Y" <?php echo ($settings['date_format'] == 'm/d/Y') ? 'selected' : ''; ?>>MM/DD/YYYY (12/31/2023)</option>
                                <option value="Y-m-d" <?php echo ($settings['date_format'] == 'Y-m-d') ? 'selected' : ''; ?>>YYYY-MM-DD (2023-12-31)</option>
                                <option value="d M Y" <?php echo ($settings['date_format'] == 'd M Y') ? 'selected' : ''; ?>>DD Mon YYYY (31 Dec 2023)</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="receipt_footer" class="form-label">Receipt Footer Message</label>
                            <textarea class="form-control" id="receipt_footer" name="receipt_footer" rows="2"><?php echo htmlspecialchars($settings['receipt_footer']); ?></textarea>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary animate-on-hover" data-hover-animation="pulse">
                    <i class="fas fa-save"></i> Save Settings
                </button>
            </form>
        </div>
    </div>
    
    <div class="card shadow mb-4 animate-fade-in" style="animation-delay: 0.2s">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">System Information</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th width="40%">PHP Version</th>
                                <td><?php echo phpversion(); ?></td>
                            </tr>
                            <tr>
                                <th>Database Type</th>
                                <td>SQLite</td>
                            </tr>
                            <tr>
                                <th>Server Software</th>
                                <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></td>
                            </tr>
                            <tr>
                                <th>Current Date/Time</th>
                                <td><?php echo date('Y-m-d H:i:s'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th width="40%">Database Size</th>
                                <td>
                                    <?php 
                                        $dbPath = 'laundry.db';
                                        echo file_exists($dbPath) ? round(filesize($dbPath) / 1024, 2) . ' KB' : 'Unknown';
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Last Database Backup</th>
                                <td>No backup yet</td>
                            </tr>
                            <tr>
                                <th>System Language</th>
                                <td>English</td>
                            </tr>
                            <tr>
                                <th>System Timezone</th>
                                <td><?php echo date_default_timezone_get(); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="mt-3">
                <a href="javascript:void(0);" class="btn btn-info animate-on-hover" data-hover-animation="pulse" onclick="alert('Database backup feature will be implemented in future updates.')">
                    <i class="fas fa-database"></i> Backup Database
                </a>
                <a href="javascript:void(0);" class="btn btn-warning animate-on-hover" data-hover-animation="pulse" onclick="alert('System update check feature will be implemented in future updates.')">
                    <i class="fas fa-sync"></i> Check for Updates
                </a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations
    initializeAnimations();
});
</script>

<?php include 'includes/footer.php'; ?>