<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Redirect to dashboard if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        // Prepare the query to prevent SQL injection
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bindParam(1, $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            // Set session variables (session already started in includes/functions.php)
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Redirect to dashboard
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Invalid username or password';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" type="image/png" href="favicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - TIBA LAUNDRY EXPRESS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4caf50;
            --info-color: #2196f3;
            --warning-color: #ff9800;
            --danger-color: #f44336;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f0f2f5;
            position: relative;
            overflow: hidden;
        }

        /* Background Animation */
        .background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: linear-gradient(-45deg, #4361ee, #3a0ca3, #4cc9f0, #4895ef);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }

        /* Floating Shapes */
        .shapes {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }

        .shape {
            position: absolute;
            display: block;
            width: 120px;
            height: 120px;
            background: rgba(255, 255, 255, 0.08);
            animation: animate 25s linear infinite;
            bottom: -150px;
            border-radius: 50%;
        }

        .shape:nth-child(1) {
            left: 25%;
            width: 80px;
            height: 80px;
            animation-delay: 0s;
        }

        .shape:nth-child(2) {
            left: 10%;
            width: 100px;
            height: 100px;
            animation-delay: 2s;
            animation-duration: 12s;
        }

        .shape:nth-child(3) {
            left: 70%;
            width: 50px;
            height: 50px;
            animation-delay: 4s;
        }

        .shape:nth-child(4) {
            left: 40%;
            width: 60px;
            height: 60px;
            animation-delay: 0s;
            animation-duration: 18s;
        }

        .shape:nth-child(5) {
            left: 65%;
            width: 40px;
            height: 40px;
            animation-delay: 0s;
        }

        .shape:nth-child(6) {
            left: 75%;
            width: 110px;
            height: 110px;
            animation-delay: 3s;
        }

        .shape:nth-child(7) {
            left: 35%;
            width: 150px;
            height: 150px;
            animation-delay: 7s;
        }

        .shape:nth-child(8) {
            left: 50%;
            width: 80px;
            height: 80px;
            animation-delay: 15s;
            animation-duration: 45s;
        }

        .shape:nth-child(9) {
            left: 20%;
            width: 30px;
            height: 30px;
            animation-delay: 2s;
            animation-duration: 35s;
        }

        .shape:nth-child(10) {
            left: 85%;
            width: 150px;
            height: 150px;
            animation-delay: 0s;
            animation-duration: 11s;
        }

        @keyframes animate {
            0% {
                transform: translateY(0) rotate(0deg);
                opacity: 1;
                border-radius: 0;
            }
            100% {
                transform: translateY(-1000px) rotate(720deg);
                opacity: 0;
                border-radius: 50%;
            }
        }

        .container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 1200px;
            padding: 0 20px;
        }

        .login-content {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        /* Left side - Branding */
        .login-branding {
            flex: 1;
            min-width: 320px;
            padding: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            animation: slide-in-left 0.8s cubic-bezier(0.250, 0.460, 0.450, 0.940) both;
        }

        @keyframes slide-in-left {
            0% {
                transform: translateX(-100px);
                opacity: 0;
            }
            100% {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .brand-logo {
            font-size: 80px;
            color: white;
            margin-bottom: 20px;
            filter: drop-shadow(0 10px 15px rgba(0, 0, 0, 0.2));
            animation: pulse 2s infinite, rotate 3s ease-in-out infinite alternate;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
            100% {
                transform: scale(1);
            }
        }

        @keyframes rotate {
            0% {
                transform: rotate(-5deg);
            }
            100% {
                transform: rotate(5deg);
            }
        }

        .brand-title {
            font-size: 36px;
            font-weight: 700;
            color: white;
            margin-bottom: 10px;
            text-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            animation: text-focus-in 1s ease-out both;
        }

        @keyframes text-focus-in {
            0% {
                filter: blur(12px);
                opacity: 0;
            }
            100% {
                filter: blur(0px);
                opacity: 1;
            }
        }

        .brand-subtitle {
            font-size: 18px;
            color: rgba(255, 255, 255, 0.8);
            max-width: 320px;
            margin: 0 auto;
            animation: fade-in 1.2s ease-out 0.5s both;
        }

        @keyframes fade-in {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Right side - Login Form */
        .login-form-container {
            flex: 1;
            min-width: 320px;
            max-width: 450px;
            padding: 20px;
            animation: slide-in-right 0.8s cubic-bezier(0.250, 0.460, 0.450, 0.940) 0.3s both;
        }

        @keyframes slide-in-right {
            0% {
                transform: translateX(100px);
                opacity: 0;
            }
            100% {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .login-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            width: 100%;
            overflow: hidden;
            position: relative;
        }

        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
            transition: 0.5s;
        }

        .login-card:hover::before {
            left: 100%;
            transition: 0.5s;
        }

        .login-header {
            margin-bottom: 30px;
            text-align: center;
        }

        .login-header h3 {
            font-size: 28px;
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 10px;
            position: relative;
            display: inline-block;
        }

        .login-header h3::after {
            content: '';
            position: absolute;
            width: 50%;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            bottom: -8px;
            left: 25%;
            border-radius: 5px;
        }

        .login-header p {
            color: #777;
            font-size: 16px;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
            transition: all 0.3s;
            opacity: 0;
            transform: translateY(-20px);
            animation: fade-in-down 0.5s forwards;
            animation-delay: calc(var(--i) * 0.1s);
        }

        @keyframes fade-in-down {
            0% {
                opacity: 0;
                transform: translateY(-20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-control-wrapper {
            position: relative;
            display: flex;
            align-items: center;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            animation: slide-up 0.5s forwards;
            opacity: 0;
            transform: translateY(20px);
            animation-delay: calc(var(--i) * 0.2s);
        }

        @keyframes slide-up {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .input-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            background-color: #f8f9fa;
            color: var(--primary-color);
            border-right: 1px solid #eaeaea;
            transition: all 0.3s ease;
        }

        .form-control {
            flex: 1;
            height: 50px;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            outline: none;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            box-shadow: none;
        }

        .form-control:focus + .input-icon {
            background-color: var(--primary-color);
            color: white;
        }

        .form-control-wrapper::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            transition: all 0.3s ease;
        }

        .form-control-wrapper:focus-within::after {
            width: 100%;
            left: 0;
        }

        .form-control-wrapper:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .login-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
            margin-top: 20px;
            height: 50px;
            animation: bounce-in 0.6s ease 1s both;
        }

        @keyframes bounce-in {
            0% {
                opacity: 0;
                transform: scale(0.3);
            }
            40% {
                opacity: 1;
                transform: scale(1.05);
            }
            60% {
                transform: scale(0.95);
            }
            100% {
                transform: scale(1);
            }
        }

        .login-btn:hover {
            background: linear-gradient(45deg, var(--secondary-color), var(--primary-color));
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.5);
            transform: translateY(-3px);
        }

        .login-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .login-btn:hover::before {
            left: 100%;
        }

        .alert-error {
            background-color: rgba(244, 67, 54, 0.1);
            color: var(--danger-color);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            animation: shake 0.5s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }

        .alert-error i {
            margin-right: 10px;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            animation: fade-in 1s ease 1.5s both;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .login-branding {
                padding: 20px;
            }
            
            .login-form-container {
                padding: 20px;
            }
            
            .login-card {
                padding: 30px;
            }
            
            .brand-title {
                font-size: 30px;
            }
        }

        @media (max-width: 768px) {
            .login-content {
                flex-direction: column;
            }
            
            .login-branding {
                order: 1;
                padding: 30px 20px;
            }
            
            .login-form-container {
                order: 2;
                padding: 0 20px 30px;
            }
            
            .brand-logo {
                font-size: 60px;
            }
            
            .brand-title {
                font-size: 24px;
            }
            
            .login-card {
                padding: 25px;
            }
        }

        /* Loading button animation */
        .loading-btn {
            position: relative;
        }

        .loading-btn .spinner {
            animation: spin 1.2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Animated Background -->
    <div class="background"></div>
    
    <!-- Animated Shapes -->
    <div class="shapes">
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    
    <div class="container">
        <div class="login-content">
            <!-- Branding Section -->
            <div class="login-branding">
                <div class="brand-logo">
                    <i class="fas fa-tshirt"></i>
                </div>
                <h1 class="brand-title">TIBA LAUNDRY EXPRESS</h1>
                <p class="brand-subtitle">Your trusted partner for clean, fresh, and professional laundry services.</p>
            </div>
            
            <!-- Login Form Section -->
            <div class="login-form-container">
                <div class="login-card">
                    <div class="login-header">
                        <h3>Welcome Back</h3>
                        <p>Enter your credentials to access your account</p>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="post" action="login.php" id="loginForm">
                        <div class="form-group">
                            <label for="username" style="--i:1">Username</label>
                            <div class="form-control-wrapper" style="--i:1">
                                <input type="text" id="username" name="username" class="form-control" placeholder="Enter your username" required>
                                <div class="input-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="password" style="--i:2">Password</label>
                            <div class="form-control-wrapper" style="--i:2">
                                <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                                <div class="input-icon">
                                    <i class="fas fa-lock"></i>
                                </div>
                            </div>
                        </div>
                        
                        <button type="submit" id="loginButton" class="login-btn">
                            <span id="buttonText"><i class="fas fa-sign-in-alt me-2"></i> Login</span>
                        </button>
                    </form>
                </div>
                
                <div class="footer">
                    <p>&copy; <?php echo date('Y'); ?> TIBA LAUNDRY EXPRESS. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Form submission animation
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const button = document.getElementById('loginButton');
            const buttonText = document.getElementById('buttonText');
            
            button.classList.add('loading-btn');
            buttonText.innerHTML = '<i class="fas fa-spinner spinner me-2"></i> Logging in...';
            button.disabled = true;
        });
        
        // Interactive form effects
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            // Focus effect with scale
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'translateY(-3px)';
                this.parentElement.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.1)';
            });
            
            // Return to normal on blur
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.style.transform = 'translateY(0)';
                    this.parentElement.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.05)';
                }
            });
            
            // Keep the effect if input has value
            input.addEventListener('input', function() {
                if (this.value) {
                    this.parentElement.classList.add('has-value');
                } else {
                    this.parentElement.classList.remove('has-value');
                }
            });
        });
        
        // Initial animation sequence
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                document.querySelector('.login-card').style.opacity = '1';
            }, 300);
        });
        
        // Password toggle visibility (optional functionality)
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.querySelector('.toggle-password i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>