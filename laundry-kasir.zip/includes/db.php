<?php
// Set error reporting (for development, disable this in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Initialize MySQL database connection
try {
    // Connect to MySQL database (with default credentials)
    $db = new PDO('mysql:host=localhost;dbname=laundry_db;charset=utf8', 'root', '');
    
    // Set error mode to exceptions for better error handling
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // If there's a database connection error, display the message and stop execution
    die("Database Error: " . $e->getMessage());
}
?>
