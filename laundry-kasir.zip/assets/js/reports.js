/**
 * Financial Reports JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize variables
    let revenueChart = null;
    let serviceTypeChart = null;
    
    // Load report data when the page loads
    loadReportData();
    
    // Handle report filter form submission
    document.getElementById('reportFilterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        loadReportData();
    });
    
    // Handle Excel export
    document.getElementById('exportExcel').addEventListener('click', function() {
        exportToExcel();
    });
    
    // Handle PDF export
    document.getElementById('exportPDF').addEventListener('click', function() {
        exportToPDF();
    });
    
    /**
     * Load report data from the server
     */
    function loadReportData() {
        const reportType = document.getElementById('report_type').value;
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        // Show loading indicators
        document.getElementById('summaryTable').innerHTML = '<tr><td colspan="2" class="text-center">Loading...</td></tr>';
        document.getElementById('reportData').innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';
        
        // Fetch report data
        fetch(`ajax/get_report_data.php?report_type=${reportType}&start_date=${startDate}&end_date=${endDate}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update summary
                    updateSummary(data.summary);
                    
                    // Update charts
                    updateCharts(data.chart_data, data.service_data);
                    
                    // Update detailed report table
                    updateReportTable(data.report_data);
                } else {
                    showToast(data.message || 'Error loading report data', 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error loading report data. Please try again.', 'danger');
                
                // For development - Show mock data if the AJAX endpoint doesn't exist yet
                showMockData();
            });
    }
    
    /**
     * Update the summary table with data
     */
    function updateSummary(summary) {
        const summaryTable = document.getElementById('summaryTable');
        
        summaryTable.innerHTML = `
            <tr>
                <td><strong>Total Orders:</strong></td>
                <td>${summary.total_orders}</td>
            </tr>
            <tr>
                <td><strong>Total Revenue:</strong></td>
                <td>${formatCurrency(summary.total_revenue)}</td>
            </tr>
            <tr>
                <td><strong>Average Order Value:</strong></td>
                <td>${formatCurrency(summary.avg_order_value)}</td>
            </tr>
        `;
    }
    
    /**
     * Update charts with data
     */
    function updateCharts(chartData, serviceData) {
        // Destroy previous charts if they exist
        if (revenueChart) {
            revenueChart.destroy();
        }
        
        if (serviceTypeChart) {
            serviceTypeChart.destroy();
        }
        
        // Create revenue chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        revenueChart = new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: 'Revenue',
                    data: chartData.values,
                    backgroundColor: 'rgba(78, 115, 223, 0.05)',
                    borderColor: 'rgba(78, 115, 223, 1)',
                    pointRadius: 3,
                    pointBackgroundColor: 'rgba(78, 115, 223, 1)',
                    pointBorderColor: 'rgba(78, 115, 223, 1)',
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: 'rgba(78, 115, 223, 1)',
                    pointHoverBorderColor: 'rgba(78, 115, 223, 1)',
                    pointHitRadius: 10,
                    pointBorderWidth: 2,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Revenue: ' + formatCurrency(context.raw);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return formatCurrency(value);
                            }
                        }
                    }
                }
            }
        });
        
        // Create service type chart
        const serviceTypeCtx = document.getElementById('serviceTypeChart').getContext('2d');
        
        // Prepare data for pie chart
        const serviceLabels = [];
        const serviceValues = [];
        const backgroundColors = [
            'rgba(78, 115, 223, 0.8)',
            'rgba(28, 200, 138, 0.8)',
            'rgba(246, 194, 62, 0.8)'
        ];
        
        serviceData.forEach((service, index) => {
            serviceLabels.push(service.service_type);
            serviceValues.push(service.total_revenue);
        });
        
        serviceTypeChart = new Chart(serviceTypeCtx, {
            type: 'pie',
            data: {
                labels: serviceLabels,
                datasets: [{
                    data: serviceValues,
                    backgroundColor: backgroundColors,
                    hoverBackgroundColor: backgroundColors.map(color => color.replace('0.8', '1')),
                    hoverBorderColor: 'rgba(234, 236, 244, 1)',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 20
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${formatCurrency(value)} (${percentage}%)`;
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    }
    
    /**
     * Update detailed report table
     */
    function updateReportTable(reportData) {
        const reportTable = document.getElementById('reportData');
        let html = '';
        
        if (reportData.length === 0) {
            html = '<tr><td colspan="5" class="text-center">No data found for the selected period</td></tr>';
        } else {
            reportData.forEach(row => {
                html += `
                    <tr>
                        <td>${row.date_label}</td>
                        <td>${row.order_count}</td>
                        <td>${formatCurrency(row.total_revenue)}</td>
                        <td>${formatCurrency(row.avg_order_value)}</td>
                        <td>
                            <button type="button" class="btn btn-sm btn-info view-detail" data-date="${row.date_group}">
                                <i class="fas fa-search"></i> Details
                            </button>
                        </td>
                    </tr>
                `;
            });
        }
        
        reportTable.innerHTML = html;
        
        // Add event listeners to detail buttons
        document.querySelectorAll('.view-detail').forEach(button => {
            button.addEventListener('click', function() {
                const date = this.getAttribute('data-date');
                showDailyDetail(date);
            });
        });
    }
    
    /**
     * Show daily detail in modal
     */
    function showDailyDetail(date) {
        const detailTable = document.getElementById('detailReportTable').querySelector('tbody');
        detailTable.innerHTML = '<tr><td colspan="7" class="text-center">Loading...</td></tr>';
        
        // Update modal title based on report type
        const reportType = document.getElementById('report_type').value;
        const modalTitle = document.getElementById('reportDetailModalLabel');
        
        if (reportType === 'daily') {
            modalTitle.textContent = 'Daily Report Detail';
        } else if (reportType === 'weekly') {
            modalTitle.textContent = 'Weekly Report Detail';
        } else {
            modalTitle.textContent = 'Monthly Report Detail';
        }
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('reportDetailModal'));
        modal.show();
        
        // Fetch daily report data
        fetch(`ajax/get_daily_report.php?date=${date}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateDetailTable(data.data);
                } else {
                    detailTable.innerHTML = `<tr><td colspan="7" class="text-center">${data.message || 'Error loading detail data'}</td></tr>`;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                detailTable.innerHTML = '<tr><td colspan="7" class="text-center">Error loading detail data. Please try again.</td></tr>';
                
                // For development - Show mock data if the AJAX endpoint doesn't exist yet
                showMockDetailData();
            });
    }
    
    /**
     * Update detail table in modal
     */
    function updateDetailTable(orders) {
        const detailTable = document.getElementById('detailReportTable').querySelector('tbody');
        let html = '';
        
        if (orders.length === 0) {
            html = '<tr><td colspan="7" class="text-center">No orders found for this period</td></tr>';
        } else {
            orders.forEach(order => {
                html += `
                    <tr>
                        <td><a href="order_form.php?id=${order.id}">${order.id}</a></td>
                        <td>${order.customer_name}</td>
                        <td>${order.service_type}</td>
                        <td>${order.weight} kg</td>
                        <td>${formatCurrency(order.total_amount)}</td>
                        <td>${order.payment_method}</td>
                        <td>${getStatusBadge(order.status)}</td>
                    </tr>
                `;
            });
        }
        
        detailTable.innerHTML = html;
    }
    
    /**
     * Export report data to Excel
     */
    function exportToExcel() {
        // Get report parameters
        const reportType = document.getElementById('report_type').value;
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        // Create a workbook
        const wb = XLSX.utils.book_new();
        
        // Get data from the report table
        const table = document.getElementById('reportsTable');
        const ws = XLSX.utils.table_to_sheet(table);
        
        // Add a title
        XLSX.utils.sheet_add_aoa(ws, [
            [`${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report: ${startDate} to ${endDate}`]
        ], { origin: 'A1' });
        
        // Add the worksheet to the workbook
        XLSX.utils.book_append_sheet(wb, ws, 'Report');
        
        // Generate Excel file and trigger download
        XLSX.writeFile(wb, `Laundry_Report_${reportType}_${startDate}_to_${endDate}.xlsx`);
    }
    
    /**
     * Export report data to PDF
     */
    function exportToPDF() {
        // Get report parameters
        const reportType = document.getElementById('report_type').value;
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        // Create a new jsPDF instance
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Add title
        doc.setFontSize(16);
        doc.text(`Laundry ${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report`, 105, 15, { align: 'center' });
        doc.setFontSize(12);
        doc.text(`Period: ${startDate} to ${endDate}`, 105, 22, { align: 'center' });
        
        // Add summary
        doc.setFontSize(14);
        doc.text('Summary', 14, 35);
        
        const summaryTable = document.getElementById('summaryTable');
        doc.autoTable({
            html: summaryTable,
            startY: 40,
            theme: 'grid',
            headStyles: { fillColor: [78, 115, 223] }
        });
        
        // Add detailed report
        doc.setFontSize(14);
        doc.text('Detailed Report', 14, doc.lastAutoTable.finalY + 15);
        
        doc.autoTable({
            html: '#reportsTable',
            startY: doc.lastAutoTable.finalY + 20,
            theme: 'grid',
            headStyles: { fillColor: [78, 115, 223] },
            columnStyles: {
                4: { cellWidth: 30 } // Adjust the width of the Details column
            },
            columns: [
                { header: 'Date', dataKey: 0 },
                { header: 'Orders', dataKey: 1 },
                { header: 'Revenue', dataKey: 2 },
                { header: 'Avg. Order Value', dataKey: 3 }
            ],
            didDrawPage: function(data) {
                // Add footer with page numbers
                doc.setFontSize(10);
                doc.text(`Page ${doc.internal.getNumberOfPages()}`, 195, 287, { align: 'right' });
            }
        });
        
        // Save the PDF
        doc.save(`Laundry_Report_${reportType}_${startDate}_to_${endDate}.pdf`);
    }
    
    /**
     * Print detail report
     */
    document.getElementById('printDetailReport').addEventListener('click', function() {
        const reportType = document.getElementById('report_type').value;
        const modalTitle = document.getElementById('reportDetailModalLabel').textContent;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
            <head>
                <title>${modalTitle}</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 20px;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                    }
                    th, td {
                        border: 1px solid #ddd;
                        padding: 8px;
                        text-align: left;
                    }
                    th {
                        background-color: #f2f2f2;
                    }
                    .badge {
                        padding: 5px 10px;
                        border-radius: 4px;
                        color: white;
                    }
                    .bg-primary { background-color: #0d6efd; }
                    .bg-warning { background-color: #ffc107; color: #000; }
                    .bg-success { background-color: #198754; }
                    .bg-secondary { background-color: #6c757d; }
                    .bg-info { background-color: #0dcaf0; }
                    @media print {
                        .no-print { display: none; }
                    }
                </style>
            </head>
            <body onload="window.print(); window.onfocus=function(){ window.close(); }">
                <div class="container">
                    <h3 class="text-center mb-4">${modalTitle}</h3>
                    <div class="table-responsive">
                        ${document.getElementById('detailReportTable').outerHTML}
                    </div>
                    <div class="text-center mt-4">
                        <p>Generated on ${new Date().toLocaleString()}</p>
                    </div>
                </div>
            </body>
            </html>
        `);
        printWindow.document.close();
    });
    
    /**
     * Show mock data for development
     */
    function showMockData() {
        // Mock summary data
        const mockSummary = {
            total_orders: 35,
            total_revenue: 1250000,
            avg_order_value: 35714.29
        };
        
        // Mock chart data
        const mockChartData = {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            values: [150000, 175000, 200000, 125000, 225000, 275000, 100000]
        };
        
        // Mock service data
        const mockServiceData = [
            { service_type: 'Cuci Kering', total_revenue: 500000 },
            { service_type: 'Cuci Setrika', total_revenue: 600000 },
            { service_type: 'Setrika Saja', total_revenue: 150000 }
        ];
        
        // Mock report data
        const mockReportData = [
            { date_label: '2023-07-01', date_group: '2023-07-01', order_count: 5, total_revenue: 175000, avg_order_value: 35000 },
            { date_label: '2023-07-02', date_group: '2023-07-02', order_count: 7, total_revenue: 245000, avg_order_value: 35000 },
            { date_label: '2023-07-03', date_group: '2023-07-03', order_count: 4, total_revenue: 140000, avg_order_value: 35000 },
            { date_label: '2023-07-04', date_group: '2023-07-04', order_count: 6, total_revenue: 210000, avg_order_value: 35000 },
            { date_label: '2023-07-05', date_group: '2023-07-05', order_count: 8, total_revenue: 280000, avg_order_value: 35000 },
            { date_label: '2023-07-06', date_group: '2023-07-06', order_count: 5, total_revenue: 200000, avg_order_value: 40000 }
        ];
        
        // Update UI with mock data
        updateSummary(mockSummary);
        updateCharts(mockChartData, mockServiceData);
        updateReportTable(mockReportData);
        
        // Show message
        showToast('Using mock data for development. In production, data would be loaded from the server.', 'info');
    }
    
    /**
     * Show mock detail data for development
     */
    function showMockDetailData() {
        const mockOrders = [
            { id: 1, customer_name: 'John Doe', service_type: 'Cuci Setrika', weight: 3.5, total_amount: 35000, payment_method: 'Tunai', status: 'Selesai' },
            { id: 2, customer_name: 'Jane Smith', service_type: 'Cuci Kering', weight: 2.0, total_amount: 14000, payment_method: 'Transfer Bank', status: 'Diambil' },
            { id: 3, customer_name: 'Bob Johnson', service_type: 'Setrika Saja', weight: 4.0, total_amount: 20000, payment_method: 'E-Wallet', status: 'Diproses' }
        ];
        
        updateDetailTable(mockOrders);
    }
});
