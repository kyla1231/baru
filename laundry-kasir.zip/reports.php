<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Check if user is admin
if (!isAdmin()) {
    setFlashMessage('danger', 'You do not have permission to access this page.');
    header('Location: dashboard.php');
    exit;
}

// Set default dates
$today = date('Y-m-d');
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : $today;
$reportType = isset($_GET['report_type']) ? $_GET['report_type'] : 'daily';

// Include header
$pageTitle = "Financial Reports";
include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800 animate-fade-in">Financial Reports</h1>
        <div>
            <button class="btn btn-success animate-on-hover" data-hover-animation="pulse" id="exportExcel">
                <i class="fas fa-file-excel"></i> Export to Excel
            </button>
            <button class="btn btn-danger animate-on-hover" data-hover-animation="pulse" id="exportPDF">
                <i class="fas fa-file-pdf"></i> Export to PDF
            </button>
        </div>
    </div>

    <?php displayFlashMessages(); ?>

    <div class="card shadow mb-4 animate-fade-in" style="animation-delay: 0.1s">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Report Filters</h6>
        </div>
        <div class="card-body">
            <form method="get" id="reportFilterForm">
                <div class="row align-items-end">
                    <div class="col-md-3 mb-3">
                        <label for="report_type" class="form-label">Report Type</label>
                        <select class="form-select" id="report_type" name="report_type">
                            <option value="daily" <?php echo ($reportType == 'daily') ? 'selected' : ''; ?>>Daily Report</option>
                            <option value="weekly" <?php echo ($reportType == 'weekly') ? 'selected' : ''; ?>>Weekly Report</option>
                            <option value="monthly" <?php echo ($reportType == 'monthly') ? 'selected' : ''; ?>>Monthly Report</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="start_date" class="form-label">Start Date</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $startDate; ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="end_date" class="form-label">End Date</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $endDate; ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <button type="submit" class="btn btn-primary w-100 animate-on-hover" data-hover-animation="pulse">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4 animate-fade-in" style="animation-delay: 0.2s">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Revenue Chart</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow mb-4 animate-fade-in" style="animation-delay: 0.3s">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Summary</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <tbody id="summaryTable">
                                <!-- Summary data will be loaded via AJAX -->
                                <tr>
                                    <td>Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="card shadow mb-4 animate-fade-in" style="animation-delay: 0.4s">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Service Type Distribution</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-2">
                        <canvas id="serviceTypeChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4 animate-fade-in" style="animation-delay: 0.5s">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Detailed Report</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="reportsTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Orders</th>
                            <th>Revenue</th>
                            <th>Avg. Order Value</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody id="reportData">
                        <!-- Report data will be loaded via AJAX -->
                        <tr>
                            <td colspan="5" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Report Detail Modal -->
<div class="modal fade" id="reportDetailModal" tabindex="-1" aria-labelledby="reportDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reportDetailModalLabel">Daily Report Detail</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered" id="detailReportTable">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Service</th>
                                <th>Weight</th>
                                <th>Amount</th>
                                <th>Payment</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Detail data will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="printDetailReport">Print</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
<script>
// Initialize animations on page load
document.addEventListener('DOMContentLoaded', function() {
    // Call animation initialization
    initializeAnimations();
    
    // Apply animations to tables after data load
    setTimeout(function() {
        animateTableRows();
    }, 1000);
});
</script>
<script src="assets/js/reports.js"></script>

<?php include 'includes/footer.php'; ?>
