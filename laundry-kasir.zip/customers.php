<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Delete customer if requested
if (isset($_GET['delete']) && isAdmin()) {
    $customer_id = (int)$_GET['delete'];
    
    // Check if customer has orders
    $stmt = $db->prepare("SELECT COUNT(*) as order_count FROM orders WHERE customer_id = ?");
    $stmt->execute([$customer_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['order_count'] > 0) {
        setFlashMessage('danger', 'Cannot delete customer with existing orders.');
    } else {
        $stmt = $db->prepare("DELETE FROM customers WHERE id = ?");
        $stmt->execute([$customer_id]);
        setFlashMessage('success', 'Customer successfully deleted');
    }
    
    header('Location: customers.php');
    exit;
}

// Include header
$pageTitle = "Manage Customers";
include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800 animate-fade-in">Manage Customers</h1>
        <a href="customer_form.php" class="btn btn-primary animate-on-hover" data-hover-animation="pulse">
            <i class="fas fa-plus"></i> New Customer
        </a>
    </div>

    <?php displayFlashMessages(); ?>

    <div class="card shadow mb-4 animate-fade-in">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">All Customers</h6>
            <div class="input-group" style="width: 300px;">
                <input type="text" id="customerSearch" class="form-control" placeholder="Search by name or phone...">
                <button class="btn btn-outline-secondary animate-on-hover" type="button" id="searchButton" data-hover-animation="pulse">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="customersTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Total Orders</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Data will be loaded via AJAX -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Customer Details Modal -->
<div class="modal fade" id="customerDetailsModal" tabindex="-1" aria-labelledby="customerDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="customerDetailsModalLabel">Customer Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Customer Information</h6>
                        <table class="table table-sm">
                            <tr>
                                <th width="30%">Name:</th>
                                <td id="customer-name"></td>
                            </tr>
                            <tr>
                                <th>Phone:</th>
                                <td id="customer-phone"></td>
                            </tr>
                            <tr>
                                <th>Address:</th>
                                <td id="customer-address"></td>
                            </tr>
                            <tr>
                                <th>Customer Since:</th>
                                <td id="customer-created"></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Order Summary</h6>
                        <table class="table table-sm">
                            <tr>
                                <th width="60%">Total Orders:</th>
                                <td id="customer-total-orders"></td>
                            </tr>
                            <tr>
                                <th>Total Spent:</th>
                                <td id="customer-total-spent"></td>
                            </tr>
                            <tr>
                                <th>Last Order:</th>
                                <td id="customer-last-order"></td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <h6>Order History</h6>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered" id="customerOrdersTable">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Service Type</th>
                                <th>Weight</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Order history will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <a href="#" class="btn btn-primary" id="editCustomerBtn">Edit Customer</a>
            </div>
        </div>
    </div>
</div>

<script>
// Call animateTableRows function from animations.js after loading data
document.addEventListener('DOMContentLoaded', function() {
    // Initialize table rows with animation after a short delay to ensure data is loaded
    setTimeout(function() {
        animateTableRows();
    }, 300);
    
    // Add row numbers after DataTable is initialized
    $('#customersTable').on('draw.dt', function() {
        $('#customersTable tbody tr').each(function(index) {
            $('td:first', this).html(index + 1);
        });
    });
});
</script>
<script src="assets/js/customers.js"></script>

<?php include 'includes/footer.php'; ?>